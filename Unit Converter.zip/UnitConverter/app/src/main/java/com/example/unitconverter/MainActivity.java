package com.example.unitconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //Declaring Widgets
    EditText editTextNumber;
    TextView textView3, textView2, textView, valueOfPounds;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Instantiating widgets

        textView = findViewById(R.id.textView);
        textView2 = findViewById(R.id.textView2);
        textView3 = findViewById(R.id.textView3);
        valueOfPounds = findViewById(R.id.valueOfPounds);

        editTextNumber = findViewById(R.id.editTextNumber);
        button = findViewById(R.id.button);

        //Adding a click event for button
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 //Calling ConvertFromKiloToPound();

                ConvertFromKiloToPound();

            }
        });
    }

    private void ConvertFromKiloToPound() {
        //This method will convert the values entered in editTextNumber from kilo to pounds.

        String valueEnteredInKilo = editTextNumber.getText().toString();

        //Converting string to number
        double Kilo = Double.parseDouble(valueEnteredInKilo);

        //Converting kilos to pound formula
        double pounds = Kilo * 2.205;

        //Displaying the value resulted in textView
        valueOfPounds.setText("" + pounds);




    }
    public void validateInput (View view){
        String input = editTextNumber.getText().toString().trim();
        if (TextUtils.isEmpty(input)) {
            Toast.makeText(this, "Please enter a number", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double inputNumber = Double.parseDouble(input);
            Toast.makeText(this, "Input is valid: " + inputNumber, Toast.LENGTH_SHORT).show();
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Input is not a number", Toast.LENGTH_SHORT).show();
        }
    }

}
